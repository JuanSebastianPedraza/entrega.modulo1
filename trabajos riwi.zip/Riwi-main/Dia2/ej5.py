nombres=["jhon","juan","antonio","steven"]
nombre = str(input("Digite su nombre"))
if nombre in nombres:
    print("correcto")
else:
    print("incorrecto")