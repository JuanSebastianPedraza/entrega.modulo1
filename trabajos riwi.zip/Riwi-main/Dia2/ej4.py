edad=int(input("digite su edad"))
if edad >120 or edad <0:
    print("No esta en el rango")
else:
    print("Esta en el rango")