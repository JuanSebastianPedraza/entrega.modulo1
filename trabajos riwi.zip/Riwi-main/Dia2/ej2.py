lista=[1,2,3,4,5]
numero=int(input("digita un numero"))
print(numero in lista)