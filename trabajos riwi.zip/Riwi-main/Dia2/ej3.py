lista2=[]
lista2.append(input("digita un nombre"))
print(lista2)