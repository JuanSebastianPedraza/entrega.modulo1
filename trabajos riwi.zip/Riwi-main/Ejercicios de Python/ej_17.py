import time
numero_inicial = 10 
while numero_inicial >= 0:
    print(numero_inicial)  
    time.sleep(1)  
    numero_inicial -= 1  
print("¡Tiempo terminado!") # Imprime el mensaje final