numero = int(input("Digite un numero: "))
if numero % 2 == 0:
    print("par")
else:
    print("inpar")