N = int(input("Ingrese el número N: "))
suma = 0
for i in range(1, N + 1):
    suma += i
print("La suma de los primeros", N, "números naturales es:", suma)