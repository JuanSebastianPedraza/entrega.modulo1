contrasena_guardada = "riwi123"
contrasena_ingresada = input("Ingrese su contraseña: ")
if contrasena_ingresada == contrasena_guardada:
    print("Contraseña correcta.")
else:
    print("Contraseña incorrecta.")