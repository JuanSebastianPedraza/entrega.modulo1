numero = int(input("Digite un numero: "))
numero2 = int(input("Digite un numero: "))
if numero > numero2:
    print(f"{numero} es mayor que {numero2}")
elif numero == numero2:
    print("ambos numeros son iguales")
else:
     print(f"{numero2} es mayor que {numero}")