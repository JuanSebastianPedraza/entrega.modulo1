numero = int(input("Digite un numero: "))
if numero > 0:
    print("Numero positivo")
elif numero < 0:
    print("Numero negativo")
else:
    print("su numero es cero")
