mi_lista = [1, 2, 3, 4, 5]
mi_lista.reverse()
print(mi_lista)