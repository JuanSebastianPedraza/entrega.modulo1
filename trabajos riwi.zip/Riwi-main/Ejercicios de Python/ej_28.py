mi_lista = [1, 2, 2, 3, 4, 2]
valor_a_contar = 2
cantidad_de_apariciones = mi_lista.count(valor_a_contar)
print(f"El valor {valor_a_contar} aparece {cantidad_de_apariciones} veces en la lista.")