numero = 10
while numero >= 1:
  print(numero)
  numero -= 1