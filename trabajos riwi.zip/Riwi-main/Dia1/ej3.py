numero = int(input("Digita un numero entero"))
if numero % 2 == 0:
    print("es numero par")
else:
    print("es numero inpar")

