numero = int(input("Digite un numero"))
if 0>=numero<=14:
    print("esta dentro del rango")
else:
    print("esta fuera del rango")