edad = int(input("cual es tu edad?"))
if edad > 18:
    print("usted es mayor de edad")
else:
    print("usted es menor de edad")