numero = int(input("Digite un numero entero"))
if numero == 0:
    print("su numero es 0")
if numero > 0:
    print("su numero es postivo")
if numero < 0:
    print("su numero es negativo")
    

    