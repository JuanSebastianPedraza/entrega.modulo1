valor = int(input("cual es el valor de su factura?"))
porc = int(input("Que propina quieres dejar? 10, 15 o 20%"))
pagar = porc / valor * 100
if porc == 10:
    print(pagar)
if porc == 15:
    print(pagar)
if porc == 20:
    print(pagar)