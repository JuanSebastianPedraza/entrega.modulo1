secreto = 10
numero = int(input("digite un numero"))
if numero == secreto:
    print("el numero es correcto")
if numero < secreto:
    print("el numero es Menor buen intento")
if numero > secreto:
    print("el numero es Mayor buen intento")