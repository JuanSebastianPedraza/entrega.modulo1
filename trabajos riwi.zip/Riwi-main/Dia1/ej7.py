numero1 = int(input("digita un numero"))
numero2 = int(input("digita otro numero"))
if numero1 == numero2:
    print("los numeros son iguales")
if numero1 > numero2:
    print(numero1)
    print("es mayor")
if numero2 > numero1:
    print(numero2)
    print("es mayor")