contrasena = str(input("Digita tu contraseña"))
if contrasena == "Riwi123":
    print("su contraseña es correcta")
else:
    print("su contraseña es incorrecta")