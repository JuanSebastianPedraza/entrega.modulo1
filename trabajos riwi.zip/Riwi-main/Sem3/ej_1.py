def saludar(nombre):
    saludo = f"Hola, {nombre}!"
    print(saludo)

saludar("Pepe")