def area_triangulo(base, altura):
  return (base * altura) / 2.0
base = 5
altura = 8
area = area_triangulo(base, altura)
print(f"El área del triángulo con base {base} y altura {altura} es: {area}")