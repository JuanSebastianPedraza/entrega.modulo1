def sumar(a, b):
  return a + b

numero1 = 5
numero2 = 10
suma = sumar(numero1, numero2)
print(f"La suma de {numero1} y {numero2} es: {suma}")