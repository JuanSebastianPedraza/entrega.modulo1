def verificar_edad():
    edad = int(input("Ingresa tu edad: "))
    if edad >= 18:
        print("Eres mayor de edad.")
    else:
        print("Eres menor de edad.")
verificar_edad()