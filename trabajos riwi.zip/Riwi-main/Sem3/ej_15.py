def invertir_cadena(cadena):

    return cadena[::-1]

# Ejemplo de uso:
cadena_original = "Hola, mundo"
cadena_invertida = invertir_cadena(cadena_original)
print(f"Cadena original: {cadena_original}")
print(f"Cadena invertida: {cadena_invertida}")