tarea=input("¿Terminaste tu tarea? (si/no) ")
if tarea!="si":
    print("Debes terminar tu tarea")
else:
    print("Excelente")