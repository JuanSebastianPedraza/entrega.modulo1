lic=input("¿Tiene licencia? (s/n) ")
cas=input("¿Tiene casco? (s/n) ")

if lic!="s" or cas!="s":
    print("No puede conducir")
else:
    print("Puede conducir")