
numero1=int(input("Ingrese un número: "))
numero2=int(input("Ingrese un número: "))

if numero1>0 and numero2>0:
    print("Ambos son positivos")
else:
    print("Alguno de los dos o los dos números no son positivos")

