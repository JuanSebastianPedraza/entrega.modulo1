Edad=int(input("Ingrese su edad: "))

if Edad>=18:
    print("Puede votar")
else:
    print("No puede votar")