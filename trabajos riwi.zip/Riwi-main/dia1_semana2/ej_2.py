Color=input("Ingrese su color favorito: ")

if Color!="rojo":
    print("Ese no es el color que esperaba")
else:
    print("Color esperado")






