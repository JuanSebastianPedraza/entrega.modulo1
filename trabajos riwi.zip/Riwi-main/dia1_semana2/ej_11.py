Lista=[]

for x in range(3):
    Nombre=input("Ingrese un nombre ")
    Lista.append(Nombre)

print(Lista)