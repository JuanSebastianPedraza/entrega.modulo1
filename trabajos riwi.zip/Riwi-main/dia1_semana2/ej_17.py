Lista=["Johan","Kevin","Tomas","Viviana", "Kevin"]

Nom=input("Ingrese un nombre para determinar cuantas veces está ")
C=Lista.count(Nom)
print(f"El nombre {Nom} está {C} veces en la lista")
