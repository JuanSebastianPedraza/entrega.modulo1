Lista=["naranja", "arroz", "manzana","mango"]
print("Lista ",Lista)
Lista.sort()
print("Lista en orden alfabetico: ", Lista)
Lista.reverse()
print("Lista en orden inverso: ", Lista)