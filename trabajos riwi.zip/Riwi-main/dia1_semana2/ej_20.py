Lista1=["Johajuann","andres","jose"]
Lista2=["Amarillo","Rojo", "Verde"]
print(Lista1)
print(Lista2)
combinar=Lista1+Lista2
print("Lista combinada: ", combinar)