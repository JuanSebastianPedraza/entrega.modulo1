temp=int(input("Ingrese la temperatura: "))

if temp<0:
    print("Hace frio")
else:
    print("No hace frio")
