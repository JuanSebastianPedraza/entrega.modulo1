
contraseña=input("Ingrese la contraseña: ")
if contraseña=="1234":
    print("Contraseña correcta")
else:
    print("Contraseña incorrecta")