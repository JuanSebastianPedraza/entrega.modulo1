num=int(input("Ingrese su nota (0-10) "))

if num<5:
    print("Perdio")

elif num>=5 and num<9:
    print("Aprobado")

elif num>=9:
    print("Sobresaliente")