Lista=["Naranja", "Pera", "Manzana","Sandia","Mango"]
print("Lista:", Lista)
Ulti=Lista.pop()
print("Se elimino", Ulti)
print("Nueva lista ",Lista)