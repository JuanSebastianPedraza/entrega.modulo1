Lista=[2,5,6,7,53,8,3,321,58,34,24,1,9,]
print("Lista: ",Lista)
Lista.sort()
print("Lista ordenada: ", Lista)
